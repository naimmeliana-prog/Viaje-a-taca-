# 🧭 Viaje a Ítaca — Arreglo de la autoactualización

Estos archivos corrigen los 5 problemas detectados en la autoactualización.

## Qué se ha cambiado y por qué

| Archivo | Cambio |
|---|---|
| `data/herramientas.js` | El cargador ahora detecta cambios **por contenido (firma/hash)**, no solo "más herramientas". Lee primero el JSON local (`data/herramientas.json`, sin CORS) y usa GitHub como respaldo. Siempre re-renderiza al detectar novedades. |
| `update_tools.py` | Avisa de forma **visible** (`::error::`/`::warning::`) si falla la clave de Gemini o los feeds. Pide a Gemini fichas completas (con ética). Lo que entre incompleto se marca `pendiente_revision` y no contamina la sección ética. **Ante error 429 (cuota) reintenta con espera creciente y prueba varios modelos** antes de caer en la heurística. |
| `build_js.py` | **NUEVO.** Regenera `data/herramientas.js` desde el JSON tras cada actualización, así la web consume de verdad lo que el bot detecta. |
| `test_gemini.py` | **NUEVO.** Diagnóstico de la clave Gemini sin gastar cuota: comprueba si es válida y qué modelos puede usar. |
| `barra-noticias.js` | **NUEVO.** Barra lateral izquierda con titulares de IA (pestañas "Novedades" y "Ética"). Autoinyectable con una sola línea. Lee `noticias.json`. |
| `noticias.json` | **NUEVO.** Titulares que genera el workflow desde los RSS. Lo consume la barra lateral. |
| `update-tools.yml` | Regenera y commitea también el JS; el paso FTP no rompe el flujo si faltan credenciales; sube JSON **y** JS a InfinityFree. |

## Cómo subirlo

### 1) A GitHub (repo `Viaje-a-taca-`)
Sube/reemplaza estos archivos respetando las rutas:

```
herramientas.json                      (raíz)
update_tools.py                        (raíz)
build_js.py                            (raíz, NUEVO)
data/herramientas.js                   (carpeta data/)
.github/workflows/update-tools.yml     (reemplaza el existente)
```

> Importante: **no** vuelvas a borrar y resubir `herramientas.json` a mano entre
> ejecuciones del bot; eso machaca lo que añade la automatización.

### 2) A InfinityFree (vía FTP, carpeta `htdocs/`)
- `data/herramientas.js`  → `htdocs/data/herramientas.js`
- `herramientas.json`     → `htdocs/data/herramientas.json`

(Si configuras los secrets FTP en GitHub, el workflow los subirá solo.)

## Secrets necesarios en GitHub (Settings → Secrets → Actions)
- `ITACA` → tu API key de Gemini (imprescindible para detectar bien).
- `FTP_HOST`, `FTP_USER`, `FTP_PASS` → opcionales; si están, sube a InfinityFree solo.

## Variables opcionales (Settings → Secrets and variables → Actions → Variables)
- `GEMINI_MODEL` → fuerza un modelo concreto (p. ej. `gemini-2.5-flash`).
  Si la dejas sin crear, el script prueba en orden:
  `gemini-2.0-flash-lite` → `gemini-2.5-flash` → `gemini-2.0-flash`.

## Activar la barra lateral de noticias
1. Sube `barra-noticias.js` a la raíz del sitio en InfinityFree (junto a las páginas .html).
2. Sube `noticias.json` a `htdocs/data/` (el workflow ya lo hace solo si tienes los secrets FTP).
3. Sustituye tus páginas .html por las de la carpeta **`paginas/`** del ZIP.
   La línea `<script src="barra-noticias.js" defer></script>` está añadida solo
   en **index.html (Inicio)** y **etica.html (Ética)**; el resto de páginas
   (herramientas, comparador, aprender) no llevan la barra.
   - Si prefieres hacerlo a mano, añade esa línea antes de `</body>` solo en esas dos páginas.

### Comportamiento de la barra
- Aparece a la izquierda con dos solapas: ✨ Novedades y ⚖️ Ética.
- **Empieza ABIERTA** en pantallas anchas (>820px) y plegada en móvil.
- Si el usuario la cierra (✕), se recuerda y no vuelve a abrirse sola (localStorage).
- Pestaña "📰 Bitácora IA". Se actualiza sola cada 30 min leyendo `noticias.json`.

## Cómo funcionan las altas automáticas (100% sin intervención humana)
Todo el proceso es autónomo. No tienes que aprobar ni revisar nada.

- Cada 2 días el sistema lee los feeds (sobre todo **Product Hunt**) y da de alta
  herramientas nuevas en `herramientas.json` (hasta 8 por ciclo).
- Recién añadidas se muestran con la etiqueta **"🆕 reciente"** mientras se
  completa su ficha.
- **La ficha se completa SOLA**: si tienes la clave Gemini (`ITACA`), cada ciclo
  rellena tipo, funciones, características, ética y precio. En cuanto la ficha
  está completa, la etiqueta "🆕 reciente" **desaparece automáticamente**.
- **Garantía de cierre automático**: si por lo que sea Gemini no pudiera
  completar una ficha, tras 3 ciclos el sistema la cierra igualmente con un texto
  autónomo (y retira la etiqueta). Así **nada se queda "reciente" para siempre**.
- **Autorregulación**: si hay 12 herramientas pendientes sin cerrar, no se añaden
  nuevas hasta que bajen, para que el catálogo no crezca sin control.

### Límites del plan gratuito (campo `limite_gratis`)
- Cada herramienta puede tener un campo `limite_gratis`: una frase que explica
  qué ofrece o qué limita su **plan gratuito** (p. ej. "GPT-5 mini ilimitado;
  GPT-5 con tope de mensajes cada pocas horas").
- Se muestra en la web como un indicador **"🎁 plan gratis"** en la tabla y una
  caja verde **"🎁 Plan gratuito: ..."** dentro de la ficha.
- **Se rellena solo**: cada ciclo, el sistema completa con Gemini el
  `limite_gratis` de unas pocas herramientas que aún no lo tengan (priorizando
  las Freemium). En varios ciclos quedan todas cubiertas. Sin clave Gemini,
  simplemente no se rellena (no rompe nada).

> Resumen: puedes no tocar nunca nada y el catálogo seguirá creciendo y
> completándose solo. Las opciones de abajo son OPCIONALES, por si algún día
> alguien quiere intervenir a mano.

### (Opcional) Editar o borrar una herramienta a mano
- Para corregir algo: edita su bloque en `herramientas.json`.
- Para borrarla: elimina su bloque `{ ... }`. Su `id` queda registrado y no se
  vuelve a añadir en el mismo ciclo.
- Para fijar una ficha como definitiva y que el sistema no la vuelva a tocar:
  pon `"pendiente_revision": false` (si no estaba ya).

## Comprobar la clave Gemini sin gastar cuota
Dos formas de usar `test_gemini.py`:

**Local (en tu ordenador):**
```bash
GEMINI_API_KEY="tu_clave" python3 test_gemini.py            # solo verifica (no gasta cuota)
GEMINI_API_KEY="tu_clave" python3 test_gemini.py --generar  # + 1 micro-llamada
```

**Desde GitHub (con el secret ITACA):** sube `test-gemini.yml` a
`.github/workflows/` y ve a Actions → "Probar clave Gemini (ITACA)" → Run workflow.
Lee el log: verás `✅ Clave VÁLIDA` y qué modelos puede usar. No toca el catálogo.

## Si ves error 429 (cuota agotada)
Significa que la clave **es válida** pero el cupo está agotado. El script ahora
reintenta solo (espera creciente) y prueba varios modelos. Aun así:
- El **cupo diario gratuito se reinicia solo** (~09:00 hora de España). Reintenta luego.
- Como el bot solo corre cada 2 días, en uso normal no deberías volver a tocarlo.
- Para listar los modelos que tu clave puede usar:
  `curl -s "https://generativelanguage.googleapis.com/v1beta/models?key=TU_CLAVE" | grep -o '"name": "[^"]*"'`

## Cómo comprobar que funciona
1. En GitHub → pestaña **Actions** → workflow "Actualizar herramientas IA" → **Run workflow** con `modo_prueba = 1`.
   - Debe añadir una "Herramienta de Prueba" al JSON (se excluye del JS público).
2. Ejecútalo con `modo_prueba = 0`. Si la clave Gemini está bien, en el log verás las herramientas detectadas; si algo falla, saldrá un aviso rojo/amarillo (ya no se queda "verde en silencio").
3. En la web, abre la consola del navegador (F12). Verás mensajes `🧭 ...`:
   - "Catálogo actualizado desde ..." cuando hay novedades.
   - "Sin novedades" cuando no las hay.
